# Grocery Store Management System (CLI Version)
# Fixed version with improved error handling and code structure

store = {
    "biscuit": {
        "sooper": [10, 20, 30, 40],
        "up": [10, 20, 40, 30],
        "peanut": [5, 10, 20, 40]
    },
    "nimko": {
        "crunch": [5, 10, 20, 30],
        "salva": [10, 20, 30, 40],
        "darbari tikka": [10, 20, 40, 50]
    }
}

buying_item = {}


def display_menu():
    """Display main menu options"""
    print('\n' + '='*50)
    print('\t\tMAIN MENU')
    print('='*50)
    print('\t1. Rate List')
    print('\t2. Customer Bill')
    print('\t3. Update Inventory')
    print('\t4. Remove Items')
    print('\t5. Exit')
    print('='*50)


def rate_list():
    """Display all products with their prices"""
    print('\n' + '='*50)
    print('\t\tRATE LIST')
    print('='*50)
    for category, items in store.items():
        print(f"\n{category.upper()}:")
        for item, prices in items.items():
            print(f"  {item}: {prices}")


def customer_bill():
    """Generate customer bill"""
    global buying_item
    buying_item = {}
    total_bill = 0
    customer = ""
    
    while True:
        print('\n' + '='*50)
        print('\t\tBILL GENERATION')
        print('='*50)
        print('\t1. Data Entry')
        print('\t2. Show Bill')
        print('\t3. Exit')
        
        choice = input('\nChoose option (1-3): ').strip()
        
        if choice == '1':
            if not customer:
                customer = input('Customer name: ').strip()
            
            try:
                n = int(input('How many items to buy: '))
                
                for i in range(n):
                    print(f"\nItem {i+1}:")
                    print(f"Available categories: {list(store.keys())}")
                    cat = input('Enter category: ').strip().lower()
                    
                    if cat not in store:
                        print(f"Error: Category '{cat}' not found!")
                        continue
                    
                    print(f"Available items: {list(store[cat].keys())}")
                    item = input('Enter item: ').strip().lower()
                    
                    if item not in store[cat]:
                        print(f"Error: Item '{item}' not found!")
                        continue
                    
                    print(f"Available prices: {store[cat][item]}")
                    idx_price = int(input(f'Choose index (0-{len(store[cat][item])-1}): '))
                    
                    if idx_price < 0 or idx_price >= len(store[cat][item]):
                        print("Error: Invalid index!")
                        continue
                    
                    price = store[cat][item][idx_price]
                    qnt = int(input('Quantity: '))
                    qprice = qnt * price
                    
                    buying_item[item] = buying_item.get(item, 0) + qprice
                    total_bill += qprice
                    
                    print(f'\nPrice of one {item} = ${price}')
                    print(f'Price of {qnt} {item} = ${qprice}')
                    
            except ValueError:
                print("Error: Please enter valid numbers!")
            except Exception as e:
                print(f"Error: {e}")
        
        elif choice == '2':
            if not customer:
                print('\nPlease enter data first!')
            else:
                print('\n' + '='*50)
                print('\t\tBILL SUMMARY')
                print('='*50)
                print(f'Customer Name: {customer}')
                print(f'\nItems Purchased:')
                for item, price in buying_item.items():
                    print(f'  {item}: ${price}')
                print(f'\nTotal Bill: ${total_bill}')
                print('='*50)
        
        else:
            break


def update_inventory():
    """Add new items to inventory"""
    while True:
        print('\n' + '='*50)
        print('\t\tUPDATE INVENTORY')
        print('='*50)
        print('\t1. Add to existing category')
        print('\t2. Create new category')
        print('\t3. Exit')
        
        choice = input('\nChoose option (1-3): ').strip()
        
        if choice == '1':
            print(f"\nAvailable categories: {list(store.keys())}")
            cat = input('Choose category: ').strip().lower()
            
            if cat not in store:
                print(f"Error: Category '{cat}' not found!")
                continue
            
            item = input('Item name: ').strip().lower()
            prices = []
            
            try:
                for i in range(4):
                    price = int(input(f'Price {i+1}: '))
                    prices.append(price)
                
                store[cat][item] = prices
                print(f'\n✓ Successfully added {item} to {cat}!')
                
            except ValueError:
                print("Error: Please enter valid numbers!")
        
        elif choice == '2':
            cat = input('New category name: ').strip().lower()
            
            if cat in store:
                print(f"Error: Category '{cat}' already exists!")
                continue
            
            item = input('First item name: ').strip().lower()
            prices = []
            
            try:
                for i in range(4):
                    price = int(input(f'Price {i+1}: '))
                    prices.append(price)
                
                store[cat] = {item: prices}
                print(f'\n✓ Successfully created category {cat} with item {item}!')
                
            except ValueError:
                print("Error: Please enter valid numbers!")
        
        else:
            break


def remove_items():
    """Remove items or categories from inventory"""
    while True:
        print('\n' + '='*50)
        print('\t\tREMOVE ITEMS')
        print('='*50)
        print('\t1. Remove item')
        print('\t2. Remove category')
        print('\t3. Exit')
        
        choice = input('\nChoose option (1-3): ').strip()
        
        if choice == '1':
            print(f"\nAvailable categories: {list(store.keys())}")
            cat = input('Choose category: ').strip().lower()
            
            if cat not in store:
                print(f"Error: Category '{cat}' not found!")
                continue
            
            print(f"Available items: {list(store[cat].keys())}")
            item = input('Item to remove: ').strip().lower()
            
            if item in store[cat]:
                del store[cat][item]
                print(f'\n✓ Successfully removed {item} from {cat}!')
                print(f'Remaining items: {store}')
            else:
                print(f"Error: Item '{item}' not found!")
        
        elif choice == '2':
            print(f"\nAvailable categories: {list(store.keys())}")
            cat = input('Category to remove: ').strip().lower()
            
            if cat in store:
                confirm = input(f'Are you sure you want to remove {cat}? (yes/no): ').strip().lower()
                if confirm == 'yes':
                    del store[cat]
                    print(f'\n✓ Successfully removed category {cat}!')
                    print(f'Remaining categories: {list(store.keys())}')
            else:
                print(f"Error: Category '{cat}' not found!")
        
        else:
            break


def main():
    """Main program loop"""
    print('\n' + '='*50)
    print('\t🛒 GROCERY STORE MANAGER')
    print('='*50)
    
    while True:
        display_menu()
        choice = input('\nChoose option (1-5): ').strip()
        
        if choice == '1':
            rate_list()
        elif choice == '2':
            customer_bill()
        elif choice == '3':
            update_inventory()
        elif choice == '4':
            remove_items()
        elif choice == '5':
            print('\n✓ Thank you for using Grocery Store Manager!')
            break
        else:
            print('\nError: Invalid choice! Please choose 1-5.')


if __name__ == "__main__":
    main()

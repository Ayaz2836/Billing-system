# 🌐 Deployment Guide

## Deploy to Streamlit Cloud (Recommended - FREE)

### Step 1: Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit: Grocery Store Manager"
git branch -M main
git remote add origin https://github.com/yourusername/grocery-store-manager.git
git push -u origin main
```

### Step 2: Deploy on Streamlit Cloud
1. Go to https://share.streamlit.io
2. Click "New app"
3. Sign in with GitHub
4. Select your repository
5. Set main file path: `app.py`
6. Click "Deploy"
7. Wait 2-3 minutes
8. Your app is live! 🎉

**Your app URL will be**: `https://yourusername-grocery-store-manager.streamlit.app`

---

## Deploy to Railway (FREE Tier Available)

### Step 1: Create Account
1. Go to https://railway.app
2. Sign up with GitHub

### Step 2: Deploy
1. Click "New Project"
2. Select "Deploy from GitHub repo"
3. Choose your repository
4. Railway auto-detects Python and deploys
5. Get your live URL

---

## Deploy to Render (FREE Tier Available)

### Step 1: Create render.yaml
Create a file named `render.yaml`:
```yaml
services:
  - type: web
    name: grocery-store-manager
    env: python
    buildCommand: pip install -r requirements.txt
    startCommand: streamlit run app.py --server.port=$PORT --server.address=0.0.0.0
```

### Step 2: Deploy
1. Go to https://render.com
2. Sign up with GitHub
3. Click "New +" → "Web Service"
4. Connect your repository
5. Render will use render.yaml config
6. Click "Create Web Service"

---

## Deploy to Heroku

### Step 1: Create Procfile
```bash
echo "web: streamlit run app.py --server.port=$PORT --server.address=0.0.0.0" > Procfile
```

### Step 2: Create setup.sh
```bash
mkdir -p ~/.streamlit/
echo "[server]
headless = true
port = $PORT
enableCORS = false
" > ~/.streamlit/config.toml
```

### Step 3: Deploy
```bash
heroku login
heroku create your-app-name
git push heroku main
heroku open
```

---

## Deploy to PythonAnywhere

### Step 1: Upload Files
1. Go to https://www.pythonanywhere.com
2. Create free account
3. Upload all files via Files tab

### Step 2: Setup
1. Open Bash console
2. Run:
```bash
pip install --user streamlit
streamlit run app.py
```

### Step 3: Configure Web App
1. Go to Web tab
2. Add new web app
3. Configure WSGI file for Streamlit

---

## Deploy to AWS (Advanced)

### Using EC2
```bash
# SSH into EC2 instance
ssh -i your-key.pem ec2-user@your-instance

# Install dependencies
sudo yum update -y
sudo yum install python3 -y
pip3 install streamlit

# Clone repo
git clone your-repo-url
cd grocery-store-manager

# Run with nohup
nohup streamlit run app.py --server.port=8501 &
```

### Using Elastic Beanstalk
1. Install EB CLI: `pip install awsebcli`
2. Initialize: `eb init -p python-3.9 grocery-store`
3. Create environment: `eb create grocery-store-env`
4. Deploy: `eb deploy`

---

## Deploy to Google Cloud Platform

### Using Cloud Run
```bash
# Create Dockerfile
echo "FROM python:3.9-slim
WORKDIR /app
COPY . .
RUN pip install -r requirements.txt
EXPOSE 8080
CMD streamlit run app.py --server.port=8080 --server.address=0.0.0.0" > Dockerfile

# Build and deploy
gcloud builds submit --tag gcr.io/PROJECT-ID/grocery-store
gcloud run deploy --image gcr.io/PROJECT-ID/grocery-store --platform managed
```

---

## Deploy to Azure

### Using Azure App Service
```bash
# Login
az login

# Create resource group
az group create --name grocery-store-rg --location eastus

# Create app service plan
az appservice plan create --name grocery-store-plan --resource-group grocery-store-rg --sku B1 --is-linux

# Create web app
az webapp create --resource-group grocery-store-rg --plan grocery-store-plan --name grocery-store-app --runtime "PYTHON|3.9"

# Deploy
az webapp up --name grocery-store-app
```

---

## Custom Domain Setup

### For Streamlit Cloud
1. Go to app settings
2. Click "Custom domain"
3. Add your domain
4. Update DNS records as shown

### For Other Platforms
1. Add CNAME record: `www.yourdomain.com` → `your-app-url`
2. Add A record: `yourdomain.com` → `platform-ip`
3. Wait for DNS propagation (up to 48 hours)

---

## Environment Variables

If you need to add secrets:

### Streamlit Cloud
1. Go to app settings
2. Click "Secrets"
3. Add in TOML format:
```toml
[secrets]
api_key = "your-key"
```

### Heroku
```bash
heroku config:set API_KEY=your-key
```

### Railway/Render
Add in dashboard under "Environment Variables"

---

## Monitoring & Analytics

### Add Google Analytics
Add to `app.py`:
```python
st.markdown("""
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
""", unsafe_allow_html=True)
```

---

## Troubleshooting

### App won't start
- Check requirements.txt has correct versions
- Verify Python version compatibility
- Check logs for errors

### Port issues
- Ensure using `$PORT` environment variable
- Set `--server.address=0.0.0.0`

### Memory issues
- Optimize session state usage
- Clear cache regularly
- Upgrade to paid tier if needed

---

## Cost Comparison

| Platform | Free Tier | Paid Plans |
|----------|-----------|------------|
| Streamlit Cloud | ✅ 1 app | $20/mo for 3 apps |
| Railway | ✅ $5 credit | $5/mo per app |
| Render | ✅ Limited | $7/mo |
| Heroku | ❌ | $7/mo |
| PythonAnywhere | ✅ Limited | $5/mo |

**Recommendation**: Start with Streamlit Cloud for easiest deployment!

---

## Need Help?

- Streamlit Docs: https://docs.streamlit.io
- Community Forum: https://discuss.streamlit.io
- GitHub Issues: Create issue in your repo

Good luck with your deployment! 🚀

     #          shop        #

#This is a grocery store in which material stock.store is a type of grocery store.

#I create dictionary which name it as     'store'
#store dictionary (line:9)
#display function (line:26)
#rate_list function (line;32)
#customer_bill function(line:42)
#update function (85 line)
#pop function (123 line)
          
store = {
"buiscuit":{
                "sooper":[10,20,30,40],
                "up":[10,20,40,30],
                'peanut':[5,10,20,40]},
'nimko':     {
                  "crunch":[5,10,20,30],
                  "salva":[10,20,30,40],
                  "darbari tikka":[10,20,40,50]}
} 



#_____________menu____________#
#menu tell us that we will have done in this program

def display():
	print('\t1. rate_list','\n,\t2.customer_ bill,','\n,\t3.update','\n,\t4.pop')

#____________rate_list_____________#
#rate list tell us the price of product which we buy

def rate_list():
	print("\t",store)
	
#____________customer bill___________#
#what will this works. it will generate bill

buying_item={}

def customer_bill():
	total_bill=0
	while True:
		print('choose[1. data entry','\n,2 .showing  bill ', '\n,3 for end')			
		choice=input('choose 1_etc :')
		if choice=='1':
		   customer=input('Customer name :')
		   
		   n=int(input('how many buying item :')) 
		   for i in range(n):
		    	    	
		    	cat=input('enter catagories(nimko l  buiscuit:')
		    	print(store[cat].keys())	
		    	items=input('enter items :')
		    	print(store[cat][items])
		    
		    	idx_price=int(input('choose index :'))
		    	price=store[cat][items][idx_price]
		    	
		   # 	print(customer)

		    	qnt=int(input('quantity'))
		    	qprice=qnt*price
		    	
		    	buying_item.update({items:qprice})
		    	total_bill+=qprice

		    	print(f'prize of one {items} = {price}')
		    	print(f'price of {qnt} {items}={qprice}')
		   
		elif choice== '2':
			   print('\tfirst of all put data and then show bill')
			   print('customer name :',customer)
			   print('buying_item :',buying_item)
			   print('total_bill  :',total_bill)
		else:
		   	print('break')
		   	break
		   		 		  		  
		   		 		  
#3___new buy material for shop____#		if we have bought the new item.so we add them.	

def update():
		n=int(input('\thow many time update items ;'))
		for i in range(n):
			choice=input('\t write 1 number for start/write other number for end :')
			
			if choice == '1':
				print('\tbefore update :',store)
				for i in range(2):
					choice=input(' \tif choose new catagory type(new) else (use old catagory): ')
					if choice =='new':
					     cat=input("\t catagory :")
					     key=input('\t key:')
					     value=input('\t [value]:')
					     new_cat={cat : {
					     key:[value]}
					     }
					     select=input('select 1 for new catagory or 2 for use old catagory ')
					     if select=='1':
					     	store.update(new_cat)
					     else:
					     	store[cat].update({key:value})
					     #store.update({key:value})
					     print(store)
					     
					elif choice =='old':
					     cat=input('choose cataogory')    
					     key=input('\tkey:')
					     value=input('tvalue :')

					     print(store)
					     
			else:
				print('breaks')
				break

#______________pop _______________#
#remove goods when goods has finished up

def pop():
	for i in range(10):
		choice =input('\tif you pop item type 1 if not want(other):')
		if choice=='1' :
			n=int(input('\thow many items remove in dictionary :'))
			for i in range(n):
				catagory=input('\tcatagory:')
			
				select=input('choose 1 or or other :')
				if select=='1':
					item=input('\titem:')
					store[catagory].pop(item)
					print('\tremaining material',store)				
				elif select=='2' :
					store.pop(catagory)
					print('\tremaining material',store)
				else:
					break	
					
		else:
			
			break
	
		#             display              #
#calling function. if we call function.so we will show result.

# display function
print ('\n,________________menu___________________')
display()

for i in range(10):
	choice=input('\tchoose (1_4 of menu) ;')

# rate_list
	if choice=='1':
		print('\n,________________rate_list_________________')
		rate_list()


# customer_bill
	elif choice=='2':
		print('\n,________________customer_bill_____________________')
		
		customer_bill()

		
#update
	elif choice=='3':
		print('\n_____________update______________')
		update()	
#pop
	elif choice=='4':
		print('\n,_______________________pop________________________')
		pop()
#end					
	elif choice:
		print('_____________________end___________________')
		break

      	
#store dictionary (line:9)
#display function (line:26)
#rate_list function (line;32)
#customer_bill function(line:42)
#update function (85 line)
#pop function (123 line)
	



	
	
# 🚀 Quick Start Guide

## Run the App Locally

1. Open terminal in this directory

2. Run the Streamlit app:
```bash
streamlit run app.py
```

3. Your browser will automatically open to `http://localhost:8501`

## First Time Setup

If you don't have Streamlit installed:
```bash
pip install -r requirements.txt
```

## Features to Try

1. **Home Page** - See your inventory overview
2. **Generate Bill** - Create a customer bill with shopping cart
3. **Rate List** - View all products and prices
4. **Add Items** - Add new products or categories
5. **Remove Items** - Delete products or categories

## Deploy to Web

### Option 1: Streamlit Cloud (Easiest)
1. Push code to GitHub
2. Go to https://share.streamlit.io
3. Connect your GitHub repo
4. Deploy!

### Option 2: Heroku
```bash
# Create Procfile first
echo "web: streamlit run app.py --server.port=$PORT" > Procfile

# Deploy
heroku create your-app-name
git push heroku main
```

### Option 3: Railway
1. Go to https://railway.app
2. Click "New Project"
3. Select "Deploy from GitHub repo"
4. Select this repository
5. Railway will auto-detect and deploy

## Troubleshooting

**Port already in use?**
```bash
streamlit run app.py --server.port 8502
```

**Module not found?**
```bash
pip install streamlit
```

**Need help?**
Check the full README.md for detailed documentation.
